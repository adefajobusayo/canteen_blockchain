package com.ebookfrenzy.duvproject.remote


import com.ebookfrenzy.duvproject.BuildConfig
import com.ebookfrenzy.duvproject.encryption.EncryptionImpl
import com.ebookfrenzy.duvproject.encryption.EncryptionInterceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import util.BASE_URL
import java.util.concurrent.TimeUnit


class RetrofitClient {
    //    private var instance: RetrofitClient? = null
//    private var myApi: Api? = null
//    val retrofit: Retrofit = Retrofit.Builder().baseUrl("")
//        .addConverterFactory(GsonConverterFactory.create())
//        .build()
//
//    myApi = re
//
//    @Synchronized
//    fun getInstance(): RetrofitClient? {
//        if (instance == null) {
//            instance = RetrofitClient()
//        }
//        return instance
//    }
//
//    fun getMyApi(): Api? {
//        return myApi
//    }
    private fun makeLoggingInterceptor(): HttpLoggingInterceptor {
        val logging = HttpLoggingInterceptor()
        HttpLoggingInterceptor.Level.BODY

        return logging
    }

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor { chain ->
            val original = chain.request()
            val requestBuilder = original.newBuilder()
                .method(original.method, original.body)
            val request = requestBuilder.build()
            chain.proceed(request)
        }
//        .addInterceptor(EncryptionInterceptor(EncryptionImpl()))
        .addInterceptor(makeLoggingInterceptor())
        .build()
    private var instance: RetrofitClient? = null
    private val retrofit: Retrofit = Retrofit.Builder().baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .client(okHttpClient)
        .build()
    private var myApi = retrofit.create(Api::class.java)

    @Synchronized
    fun getInstance(): RetrofitClient? {
        if (instance == null) {
            instance = RetrofitClient()
        }
        return instance
    }

    fun getApi(): Api = myApi
}