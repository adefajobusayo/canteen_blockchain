package com.ebookfrenzy.duvproject.data

data class UserLogin(
    val email: String,
    val password: String
)
