package com.ebookfrenzy.duvproject

import android.app.Application

class App: Application() {
    override fun onCreate() {
        super.onCreate()
//        PaymentConfiguration.init(
//            applicationContext,
//            "pk_test_51N9t67IT7W9tGjKguaZCI4I8RuBOiTTjIjKuegGUu8qOqd1OihUedbTy595DwmiGfALkGhfPvsIwK1ick5tFnOvQ00iFqHnKjX"
//        )
    }
}