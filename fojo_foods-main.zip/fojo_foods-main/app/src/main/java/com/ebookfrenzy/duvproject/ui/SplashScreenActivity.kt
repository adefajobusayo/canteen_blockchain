package com.ebookfrenzy.duvproject.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.ebookfrenzy.duvproject.R
import kotlinx.coroutines.*

class SplashScreenActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.splash_screen_activity)

        GlobalScope.launch {
            delay(1000L)
            withContext(Dispatchers.Main) {
                val intent = Intent(this@SplashScreenActivity, com.ebookfrenzy.duvproject.ui.AuthenticationActivity::class.java)
                startActivity(intent)
            }
        }
    }
}
