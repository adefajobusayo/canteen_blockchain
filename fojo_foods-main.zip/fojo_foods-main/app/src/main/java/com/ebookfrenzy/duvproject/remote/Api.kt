package com.ebookfrenzy.duvproject.remote

import com.ebookfrenzy.duvproject.data.NewUserResponse
import com.ebookfrenzy.duvproject.data.OrderResponse
import com.ebookfrenzy.duvproject.data.Product
import com.ebookfrenzy.duvproject.data.UserLogin
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.http.*

interface Api {
    @POST("login")
    fun userLogin(
        @Body userLogin: UserLogin
    ): Call<Unit>

    @Headers("Content-Type: multipart/form-data")
    @POST("register")
    fun userSignup(
        @Body requestBody: RequestBody
//        @Part("firstName") firstName: RequestBody?,
//        @Part("lastName") lastName: RequestBody?,
//        @Part("address") address: RequestBody?,
//        @Part("userType") userType: RequestBody?,
//        @Part("dob") dob: RequestBody?,
//        @Part("email") email: RequestBody?,
//        @Part("password") password: RequestBody?,
//        @Part("userAuthority") userAuthority: RequestBody?
    ): Call<NewUserResponse>

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GET("foods")
    fun fetchFoods(
        @Header("Authorization") authorization: String
    ): Call<Product>

    @Headers("Content-Type: application/json;charset=UTF-8")
    @POST("foods/{id}/pay")
    fun orderFood(
        @Header("Authorization") authorization: String,
        @Path("id") id: String
    ): Call<OrderResponse>

}