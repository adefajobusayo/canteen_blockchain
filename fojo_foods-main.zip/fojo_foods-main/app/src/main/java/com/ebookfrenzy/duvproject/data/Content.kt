package com.ebookfrenzy.duvproject.data

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Content(
    val amount: Double,
    val description: String,
    val id: String,
    val img: String,
    val name: String
): Parcelable{
    fun price() = "N$amount"
}