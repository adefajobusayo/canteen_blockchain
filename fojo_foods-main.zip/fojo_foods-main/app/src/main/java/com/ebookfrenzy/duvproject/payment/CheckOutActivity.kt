package com.ebookfrenzy.duvproject.payment

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.ebookfrenzy.duvproject.R

class CheckOutActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_check_out)
        startCheckout()
    }
    private fun startCheckout() {
        // Request a PaymentIntent from your server and store its client secret in paymentIntentClientSecret
        // Click View full sample to see a complete implementation
    }
}