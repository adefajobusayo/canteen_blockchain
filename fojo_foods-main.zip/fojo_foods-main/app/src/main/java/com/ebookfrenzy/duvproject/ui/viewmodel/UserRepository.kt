package com.ebookfrenzy.duvproject.ui.viewmodel

import com.ebookfrenzy.duvproject.remote.RetrofitClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class UserRepository {
//    val retrofitClient = RetrofitClient().getInstance()
//
//    suspend fun userLogin(email: String, password: String): Call<Unit> {
//        try {
//            withContext(Dispatchers.IO) {
//                retrofitClient?.getApi()?.userLogin(email, password)?.enqueue(object : Callback<Unit>{
//                    override fun onResponse(call: Call<Unit>, response: Response<Unit>) {
//                        response.
//                    }
//
//                    override fun onFailure(call: Call<Unit>, t: Throwable) {
//                        TODO("Not yet implemented")
//                    }
//                })
//            }
//        } catch (e: Exception){
//            e.toString()
//        }
//    }
}