package com.ebookfrenzy.duvproject.data

data class SortX(
    val empty: Boolean,
    val sorted: Boolean,
    val unsorted: Boolean
)