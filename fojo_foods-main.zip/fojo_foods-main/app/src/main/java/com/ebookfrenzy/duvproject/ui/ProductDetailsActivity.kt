package com.ebookfrenzy.duvproject.ui

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.webkit.WebChromeClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.browser.customtabs.CustomTabsIntent
import com.bumptech.glide.Glide
import com.ebookfrenzy.duvproject.R
import com.ebookfrenzy.duvproject.data.Content
import com.ebookfrenzy.duvproject.data.OrderResponse
import com.ebookfrenzy.duvproject.databinding.ActivityProductDetailsBinding
import com.ebookfrenzy.duvproject.remote.RetrofitClient
import com.flutterwave.raveandroid.RaveUiManager
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import timber.log.Timber
import util.BASE_URL
import java.util.*


class ProductDetailsActivity : AppCompatActivity() {
    lateinit var binding: ActivityProductDetailsBinding
    private var content: Content? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProductDetailsBinding.inflate(layoutInflater)
        content = intent.getParcelableExtra("product", Content::class.java)
        setContentView(binding.root)

        binding.product = content
        title = content?.name ?: "Details"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        Glide.with(this)
            .load(BASE_URL.substring(0, 49) + (content?.img?.substring(28) ?: ""))
            .error(R.drawable.ic_outline_shopping)
            .into(binding.prodImage)

        binding.orderBtn.setOnClickListener { orderFood() }

        binding.webview.settings.javaScriptEnabled = true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    fun initializeFlutterwavePayment(
        amount: Double,
        email: String,
        fName: String,
        lName: String,
        narration: String,
        phoneNumber: String,
        txRef: String
    ) {
        RaveUiManager(this)
            .setAmount(amount)
            .setCurrency("NGN")
            .setEmail(email)
            .setfName(fName)
            .setlName(lName)
            .setNarration(narration)
            .setPublicKey("FLWPUBK_TEST-aedf85dcdc301996d7f69472c9e87041-X")
            .setEncryptionKey("FLWSECK_TEST20c281c64b28")
            .setTxRef(txRef)
            .setPhoneNumber(phoneNumber, false)
            .acceptAccountPayments(true)
            .acceptCardPayments(true)
            .acceptMpesaPayments(false)
            .acceptAchPayments(false)
            .acceptGHMobileMoneyPayments(false)
            .acceptUgMobileMoneyPayments(false)
            .acceptZmMobileMoneyPayments(false)
            .acceptRwfMobileMoneyPayments(false)
            .acceptSaBankPayments(false)
            .acceptUkPayments(false)
            .acceptBankTransferPayments(true)
            .acceptUssdPayments(true)
            .acceptBarterPayments(true)
            .acceptFrancMobileMoneyPayments(false, "Nigeria")
            .allowSaveCardFeature(true)
            .onStagingEnv(true)
            .initialize();
    }

    fun generateTransactionReference(): String {
        // Generate a random UUID (Universally Unique Identifier)
        val uuid: UUID = UUID.randomUUID()

        // Convert UUID to a string and remove hyphens
        return uuid.toString().replace("-", "")
    }

    private fun orderFood() {
        try {
            val prefs: SharedPreferences? =
                this@ProductDetailsActivity.getSharedPreferences("appPrefs", Context.MODE_PRIVATE)
            val token = prefs?.getString("token", "")
            val client = RetrofitClient().getInstance()

            content?.let {
                if (token != null) {
                    client?.getApi()?.orderFood(token, it.id)
                        ?.enqueue(object : Callback<OrderResponse> {
                            override fun onResponse(
                                call: Call<OrderResponse>,
                                response: Response<OrderResponse>
                            ) {
                                Log.d("TOKEN", response.code().toString())
//                                Toast.makeText(
//                                    this@ProductDetailsActivity,
//                                    response.body()?.data?.hosted_url ?: "No url",
//                                    Toast.LENGTH_LONG
//                                ).show()
                                val url = response.body()!!.data.hosted_url
                                openInChrome(url)
                            }

                            override fun onFailure(call: Call<OrderResponse>, t: Throwable) {
                                Timber.d(t)
                            }
                        })
                }
            }
        } catch (e: Exception) {
            Timber.e(e.message)
        }

    }

    private fun openInChrome(url: String){
        val builder = CustomTabsIntent.Builder()
        val customTabsIntent = builder.build()
        val uri = Uri.parse(url)
//        customTabsIntent.launchUrl(this, uri)

        val packageName = "com.android.chrome"
        customTabsIntent.intent.setPackage(packageName)
        customTabsIntent.launchUrl(this, uri)
    }

    private fun openWebview(url: String){
        binding.webview.webChromeClient = WebChromeClient()
        binding.webview.loadUrl(url)
    }
}