package com.ebookfrenzy.duvproject.data

data class OnBoardingData(var title: String, var desc: String, var imageUrl: Int)
