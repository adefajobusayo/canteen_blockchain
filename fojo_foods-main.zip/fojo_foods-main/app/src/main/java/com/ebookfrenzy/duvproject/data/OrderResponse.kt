package com.ebookfrenzy.duvproject.data

data class OrderResponse(
    val `data`: Data
)

data class Data(
    val addresses: Addresses,
    val code: String,
    val description: String,
    val fees_settled: Boolean,
    val hosted_url: String,
    val payments: List<Any>
)

data class Addresses(
    val bitcoin: String,
    val ethereum: String,
    val polygon: String,
    val pusdc: String,
    val usdc: String
)