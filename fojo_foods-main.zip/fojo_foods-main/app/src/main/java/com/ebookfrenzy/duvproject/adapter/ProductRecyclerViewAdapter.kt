package com.ebookfrenzy.duvproject.adapter


import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.model.GlideUrl
import com.bumptech.glide.load.model.LazyHeaders
import com.ebookfrenzy.duvproject.R
import com.ebookfrenzy.duvproject.data.Content
import com.ebookfrenzy.duvproject.databinding.ProductsItemLayoutBinding
import util.BASE_URL
import util.TOKEN

class ProductRecyclerViewAdapter(private val itemClickListener: com.ebookfrenzy.duvproject.adapter.ProductRecyclerViewAdapter.ItemClickListener) :
    ListAdapter<Content, RecyclerView.ViewHolder>(DiffCallback()) {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view = DataBindingUtil.inflate<ProductsItemLayoutBinding>(
            LayoutInflater.from(parent.context),
            R.layout.products_item_layout,
            parent,
            false
        )
        return ProductViewHolder(view,parent.context)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is ProductViewHolder) holder.bind(getItem(position),itemClickListener)
    }

    inner class ProductViewHolder(private val binding: ProductsItemLayoutBinding,private val context: Context) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(
            product: Content,
            clickListener: com.ebookfrenzy.duvproject.adapter.ProductRecyclerViewAdapter.ItemClickListener
        ) {
            binding.clickListener = clickListener
            binding.product = product
            val glideUrl = GlideUrl(BASE_URL.substring(0,49)+product.img.substring(28),LazyHeaders.Builder()
                .addHeader("Authorization", TOKEN)
                .build()
            )
            Glide.with(context)
                .load(glideUrl)
                .error(R.drawable.ic_outline_shopping)
                .into(binding.itemImage);
        }

    }
    class DiffCallback : DiffUtil.ItemCallback<Content>() {
        override fun areItemsTheSame(oldItem: Content, newItem: Content): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Content, newItem: Content): Boolean {
            return oldItem == newItem
        }
    }
    interface ItemClickListener {
        fun onItemClicked(product: Content)
    }
}