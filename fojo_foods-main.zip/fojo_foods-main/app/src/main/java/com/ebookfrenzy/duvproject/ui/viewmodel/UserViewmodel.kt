package com.ebookfrenzy.duvproject.ui.viewmodel

import androidx.lifecycle.ViewModel

class UserViewmodel: ViewModel() {

}