package com.ebookfrenzy.duvproject.data

data class NewUserResponse(
    val httpStatus: String,
    val message: String,
    val response: Response
)

data class Response(
    val address: String,
    val authority: String,
    val bankAccountVerified: Boolean,
    val dob: String,
    val email: String,
    val firstName: String,
    val lastName: String,
    val pk: String,
    val userVerified: Boolean
)