package com.ebookfrenzy.duvproject.encryption

import android.os.Build
import androidx.annotation.RequiresApi

interface CryptoStrategy {
    @Throws(Exception::class)
    fun encrypt(body: String?): String

    @Throws(Exception::class)
    fun decrypt(data: String?): String?
}

class EncryptionImpl : CryptoStrategy {
    @Throws(Exception::class)
    override fun encrypt(body: String?): String {
        return body?.let { AESEncryption().encrypt(it) }!!
    }

    override fun decrypt(data: String?): String? {
        return null
    }
}