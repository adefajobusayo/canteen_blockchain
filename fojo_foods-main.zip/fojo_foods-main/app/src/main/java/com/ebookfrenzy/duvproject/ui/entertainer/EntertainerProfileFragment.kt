package com.ebookfrenzy.duvproject.ui.entertainer

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.ebookfrenzy.duvproject.adapter.ProductRecyclerViewAdapter
import com.ebookfrenzy.duvproject.adapter.ProductRecyclerViewAdapter.ItemClickListener
import com.ebookfrenzy.duvproject.data.Content
import com.ebookfrenzy.duvproject.data.Product
import com.ebookfrenzy.duvproject.databinding.FragmentDashboardBinding
import com.ebookfrenzy.duvproject.remote.RetrofitClient
import com.ebookfrenzy.duvproject.ui.ProductDetailsActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import util.TOKEN

class EntertainerProfileFragment : Fragment(), ItemClickListener {
    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!
    lateinit var swipeRefreshLayout: SwipeRefreshLayout

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentDashboardBinding.inflate(inflater,container,false)
        swipeRefreshLayout = binding.swipeToRefresh
        // Inflate the layout for this fragment
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        fetchItems()
        swipeRefreshLayout.setOnRefreshListener { fetchItems() }
    }

    private fun fetchItems(){

        swipeRefreshLayout.isRefreshing = true
        try {
            val prefs: SharedPreferences? =
            requireContext().getSharedPreferences("appPrefs", Context.MODE_PRIVATE)
            val token = prefs?.getString("token","")
            val client = RetrofitClient().getInstance()
            if (token != null) {
                client?.getApi()?.fetchFoods(token)?.enqueue(object : Callback<Product>{
                    override fun onResponse(call: Call<Product>, response: Response<Product>) {
                        swipeRefreshLayout.isRefreshing = false
                        if (response.isSuccessful){
                            val product = response.body()
                            Log.e("FETCH-FOODS",product.toString())
                            if (product != null) {
                                setupRecyclerView(product.content)
                            }
                        }
                    }

                    override fun onFailure(call: Call<Product>, t: Throwable) {
                        swipeRefreshLayout.isRefreshing = false
                        Log.e("FETCH-FOODS",t.message.toString())
                    }
                })
            }
        }catch (e: Exception){
            Log.e("FETCH-FOODS",e.message.toString())
        }
    }

    fun setupRecyclerView(foods: List<Content>){
        val adapter = ProductRecyclerViewAdapter(this)
        adapter.submitList(foods)
        val recyclerView = binding.productsRecyclerview
        recyclerView.adapter = adapter
    }

    override fun onItemClicked(product: Content) {
        val intent = Intent(requireActivity(), ProductDetailsActivity::class.java)
        intent.putExtra("product",product)
        startActivity(intent)
    }
}
