package util

import android.graphics.Color
import android.graphics.Typeface
import android.text.Spannable
import android.text.SpannableString
import android.text.TextPaint
import android.text.style.ClickableSpan
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.view.View
import android.widget.TextView

object UtilityFunctions {

//    lateinit var haveAnAccountLoginText: TextView
//
//    fun spanLoginText() {
//        // set the spannable text
//        val spannableString = SpannableString("Have an account?  Login")
//
//        // set the spannable image
//        val fColor = ForegroundColorSpan(Color.WHITE)
//        val sizeSpan = RelativeSizeSpan(1.1f)
//        val styleSpan = StyleSpan(Typeface.BOLD)
//        val clickableSpan = object : ClickableSpan() {
//            override fun onClick(widget: View) {
////                Toast.makeText(requireContext(), "nice one", Toast.LENGTH_SHORT).show()
//            }
//
//            override fun updateDrawState(ds: TextPaint) {
//                super.updateDrawState(ds)
//                ds.isUnderlineText = false
//            }
//        }
//
//        spannableString.setSpan(clickableSpan, 18, 23, Spannable.SPAN_INCLUSIVE_EXCLUSIVE)
//        spannableString.setSpan(fColor, 18, 23, Spannable.SPAN_INCLUSIVE_EXCLUSIVE)
//        spannableString.setSpan(sizeSpan, 18, 23, Spannable.SPAN_INCLUSIVE_EXCLUSIVE)
//        spannableString.setSpan(styleSpan, 18, 23, Spannable.SPAN_INCLUSIVE_EXCLUSIVE)
//
//        haveAnAccountLoginText.text = spannableString
//    }
}
